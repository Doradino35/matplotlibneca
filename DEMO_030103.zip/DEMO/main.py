from fastapi import FastAPI, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import engine, get_db
from auth import admin_auth as auth
from crud import admin_crud as crud
from models import admin_models as models
from schema import admin_schema as schema

models.Base.metadata.create_all(bind=engine)

app = FastAPI()


@app.post("/users/", response_model=schema.User)
def create_user(user: schema.UserCreate, db: Session = Depends(get_db)):
    if not (1 <= len(user.name) <= 50):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Name must be between 1 and 50 characters")
    if not (1 <= len(user.description) <= 255):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Description must be between 1 and 255 characters")

    db_user = models.User(**user.dict())
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


@app.get("/users/{username}", response_model=schema.User)
def read_user(username: str, db: Session = Depends(get_db)):
    user = crud.get_user(db, username)
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return user


@app.get("/admin")
def get_admin(username: str = Depends(auth.get_current_username)):
    return {"username": username}


@app.post("/teachers/", response_model=schema.Teacher)
def signup_teacher(teacher: schema.TeacherCreate, db: Session = Depends(get_db),
                   current_user: str = Depends(auth.get_current_user)):
    db_user = crud.get_teacher_by_email(db, current_user)
    if db_user.role != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                            detail="You are not the admin, contact the appropriate desk to create an account.")

    db_teacher = crud.get_teacher_by_email(db, teacher.email)
    if db_teacher:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already registered")
    return crud.create_teacher(db=db, teacher=teacher)


@app.get("/teachers/", response_model=list[schema.Teacher])
def read_teachers(db: Session = Depends(get_db), current_user: str = Depends(auth.get_current_user)):
    db_teacher = crud.get_teacher_by_email(db, current_user)
    if db_teacher.role != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="You do not have permission")

    return crud.get_all_teachers(db)


@app.get("/teachers/{email}", response_model=schema.Teacher)
def read_teacher(email: str, db: Session = Depends(get_db), current_user: str = Depends(auth.get_current_user)):
    db_teacher = crud.get_teacher_by_email(db, email)
    if db_teacher is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Teacher not found")
    return db_teacher


@app.put("/teachers/{email}", response_model=schema.Teacher)
def update_teacher(email: str, teacher: schema.TeacherCreate, db: Session = Depends(get_db), current_user: str = Depends(auth.get_current_user)):
    db_teacher = crud.update_teacher(db, email, teacher)
    if db_teacher is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Teacher not found")
    return db_teacher


@app.delete("/teachers/{email}", response_model=schema.Teacher)
def delete_teacher(email: str, db: Session = Depends(get_db), current_user: str = Depends(auth.get_current_user)):
    db_teacher = crud.delete_teacher(db, email)
    if db_teacher is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Teacher not found")
    return db_teacher


@app.post("/students/", response_model=schema.Student)
async def signup_student(student: schema.StudentCreate, db: Session = Depends(get_db),
                         current_user: str = Depends(auth.get_current_user)):
    db_user = crud.get_student_by_id(db, current_user)
    if db_user.role != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                            detail="You are not the admin, contact your class teacher for assistance.")

    db_student = crud.get_student_by_id(db, student.id)
    if db_student:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST,
                            detail="Student with provided details already exists on this database")
    return crud.create_student(db=db, student=student)


@app.get("/students/", response_model=list[schema.Student])
def read_students(db: Session = Depends(get_db)):
    return crud.get_all_students(db)


@app.get("/students/{student_id}", response_model=schema.Student)
def read_student(student_id: int, db: Session = Depends(get_db)):
    db_student = crud.get_student_by_id(db, student_id)
    if db_student is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student not found")
    return db_student


@app.put("/students/{student_id}", response_model=schema.Student)
def update_student(student_id: int, student: schema.StudentCreate, db: Session = Depends(get_db)):
    db_student = crud.update_student(db, student_id, student)
    if db_student is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Student not found")
    return db_student


@app.delete("/students/{student_id}", response_model=schema.Student)
def delete_student(student_id: int, db: Session = Depends(get_db)):
    db_student = crud.delete_student(db, student_id)
    if db_student is None:
        raise HTTPException(status_code=404, detail="Student not found")
    return db_student
