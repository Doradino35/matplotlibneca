from schema.admin_schema import TeacherCreate, StudentCreate
from models.admin_models import User, Teacher, Student
from passlib.context import CryptContext
from sqlalchemy.orm import Session
import logging

logger = logging.getLogger(__name__)

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def create_teacher(db: Session, teacher: TeacherCreate):
    hashed_password = pwd_context.hash(teacher.password)
    db_teacher = Teacher(**teacher.dict(), password=hashed_password)
    db.add(db_teacher)
    db.commit()
    db.refresh(db_teacher)
    return db_teacher


def create_student(db: Session, student: StudentCreate):
    db_student = Student(**student.dict())
    db.add(db_student)
    db.commit()
    db.refresh(db_student)
    return db_student


def get_teacher_by_email(db: Session, email: str):
    return db.query(Teacher).filter(Teacher.email == email).first()


def get_student_by_id(db: Session, id: int):
    return db.query(Student).filter(Student.id == id).first()


def get_all_teachers(db: Session):
    return db.query(Teacher).all()


def get_all_students(db: Session):
    return db.query(Student).all()


def update_teacher(db: Session, email: str, teacher: TeacherCreate):
    db_teacher = get_teacher_by_email(db, email)
    if db_teacher:
        db_teacher.name = teacher.name
        db_teacher.email = teacher.email
        db_teacher.year = teacher.year
        db_teacher.subject = teacher.subject
        if teacher.password:
            db_teacher.password = pwd_context.hash(teacher.password)
        db.commit()
        db.refresh(db_teacher)
    return db_teacher


def update_student(db: Session, student_id: int, student: StudentCreate):
    db_student = get_student_by_id(db, student_id)
    if db_student:
        db_student.name = student.name
        db_student.age = student.age
        db_student.year = student.year
        db.commit()
        db.refresh(db_student)
    return db_student


def delete_teacher(db: Session, email: str):
    db_teacher = get_teacher_by_email(db, email)
    if db_teacher:
        db.delete(db_teacher)
        db.commit()
    return db_teacher


def delete_student(db: Session, student_id: int):
    db_student = get_student_by_id(db, student_id)
    if db_student:
        db.delete(db_student)
        db.commit()
    return db_student
