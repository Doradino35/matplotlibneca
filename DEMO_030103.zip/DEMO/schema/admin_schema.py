from pydantic import BaseModel, EmailStr
from enum import Enum


class Role(str, Enum):
    admin = "admin"
    teacher = "teacher"
    student = "student"


class UserBase(BaseModel):
    username: str


class UserCreate(UserBase):
    name: str
    password: str
    role: Role


class User(UserBase):
    id: int

    class Config:
        from_attributes = True


class TeacherCreate(BaseModel):
    name: str
    email: EmailStr
    subject: str
    password: str


class Teacher(TeacherCreate):
    id: int

    class Config:
        from_attributes = True


class StudentCreate(BaseModel):
    name: str
    age: int
    year: str


class Student(StudentCreate):
    id: int

    class Config:
        from_attributes = True
